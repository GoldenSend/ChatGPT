# GPU-022 part B: 7 dispatches. Sourced by tools/gpu022_gate.sh.
run B1_f16r unit_exact_lib.comp --groups 4096 --in "0:$I/a229010b90378065d180e2d6.bin" --out "1:$O/B1_f16r.bin:1101384" --int mode=0 --int n=275346
run B2_glibc_expf unit_exact_lib.comp --groups 1153 --in "0:$I/3be4705d2d9cc8258ecd91cd.bin" --out "1:$O/B2_glibc_expf.bin:294920" --int mode=1 --int n=73730
run B3_rcp_cr unit_exact_lib.comp --groups 1152 --in "0:$I/521c8a4e21af20f7cd5563fb.bin" --out "1:$O/B3_rcp_cr.bin:294912" --int mode=2 --int n=73728
run B4_ggml_v_expf unit_exact_lib.comp --groups 1152 --in "0:$I/a844a0a2b96f7e98c875b3ab.bin" --out "1:$O/B4_ggml_v_expf.bin:294912" --int mode=3 --int n=73728
run B5_sqrt_cr unit_exact_lib.comp --groups 1024 --in "0:$I/38e4936c23f88d8d5051b86b.bin" --out "1:$O/B5_sqrt_cr.bin:262144" --int mode=4 --int n=65536
run B6_silu unit_exact_lib.comp --groups 1280 --in "0:$I/c785dcbbaeb62105096e338b.bin" --out "1:$O/B6_silu.bin:327680" --int mode=5 --int n=81920
run B7_rms_norm ggml_rms_norm_mul.comp --groups 256 --in "0:$I/7746fbae578fa902c68b05c5.bin" --in "1:$I/1ed30b0a82d31b87c619e1c7.bin" --in "2:$I/3f36b37ad9256c75b676d3be.bin" --out "3:$O/B7_rms_norm.bin:1048576"
