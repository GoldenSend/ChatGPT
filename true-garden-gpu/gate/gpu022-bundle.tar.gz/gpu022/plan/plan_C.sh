# GPU-022 part C: 182 dispatches. Sourced by tools/gpu022_gate.sh.
run C0_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/104e1764c42d101e18f57fd5.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C0_01_attn_norm.bin:4096"
run C0_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C0_01_attn_norm.bin" --out "1:$O/C0_02_Qcur_q8k.bin:4368"
run C0_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C0_02_Qcur_q8k.bin" --out "3:$O/C0_03_Qcur.bin:8192"
run C0_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C0_01_attn_norm.bin" --out "1:$O/C0_04_Kcur_q8k.bin:4368"
run C0_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C0_04_Kcur_q8k.bin" --out "3:$O/C0_05_Kcur.bin:4096"
run C0_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C0_01_attn_norm.bin" --out "1:$O/C0_06_Vcur_q8k.bin:4368"
run C0_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C0_06_Vcur_q8k.bin" --out "3:$O/C0_07_Vcur.bin:4096"
run C0_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C0_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C0_08_Qcur_normed.bin:8192"
run C0_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C0_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C0_09_Kcur_normed.bin:4096"
run C0_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C0_08_Qcur_normed.bin" --in "2:$I/cd7e9627ec9cd9a96d820930.bin" --out "3:$O/C0_10_Qrope.bin:8192"
run C0_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C0_09_Kcur_normed.bin" --in "2:$I/cd7e9627ec9cd9a96d820930.bin" --out "3:$O/C0_11_Krope.bin:4096"
run C0_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C0_11_Krope.bin" --in "1:$O/C0_11_Krope.bin" --out "2:$O/C0_12_kpack.bin:2048" --int mode=2 --int n=1024
run C0_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C0_07_Vcur.bin" --in "1:$O/C0_07_Vcur.bin" --out "2:$O/C0_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C0_kcache.bin $O/C0_12_kpack.bin
concat $O/C0_vcache.bin $O/C0_13_vpack.bin
run C0_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/c0ea235ceb15ecd31c28ed19.bin" --in "1:$O/C0_10_Qrope.bin" --in "2:$O/C0_kcache.bin" --in "3:$O/C0_vcache.bin" --out "4:$O/C0_14_kqv_out.bin:8192"
run C0_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C0_14_kqv_out.bin" --out "1:$O/C0_15_attn_out_q8k.bin:8736"
run C0_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C0_15_attn_out_q8k.bin" --out "3:$O/C0_16_attn_out.bin:4096"
run C0_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C0_16_attn_out.bin" --in "1:$I/104e1764c42d101e18f57fd5.bin" --out "2:$O/C0_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C0_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C0_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C0_18_ffn_norm.bin:4096"
run C0_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C0_18_ffn_norm.bin" --out "1:$O/C0_19_ffn_gate_q8k.bin:4368"
run C0_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C0_19_ffn_gate_q8k.bin" --out "3:$O/C0_20_ffn_gate.bin:12288"
run C0_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C0_18_ffn_norm.bin" --out "1:$O/C0_21_ffn_up_q8k.bin:4368"
run C0_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C0_21_ffn_up_q8k.bin" --out "3:$O/C0_22_ffn_up.bin:12288"
run C0_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C0_20_ffn_gate.bin" --in "1:$O/C0_22_ffn_up.bin" --out "2:$O/C0_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C0_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C0_23_ffn_swiglu.bin" --out "1:$O/C0_24_ffn_out_q8k.bin:13104"
run C0_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C0_24_ffn_out_q8k.bin" --out "3:$O/C0_25_ffn_out.bin:4096"
run C0_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C0_25_ffn_out.bin" --in "1:$O/C0_17_ffn_inp.bin" --out "2:$O/C0_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step0
run C1_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/835059c1d15815325db5d1b6.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C1_01_attn_norm.bin:4096"
run C1_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C1_01_attn_norm.bin" --out "1:$O/C1_02_Qcur_q8k.bin:4368"
run C1_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C1_02_Qcur_q8k.bin" --out "3:$O/C1_03_Qcur.bin:8192"
run C1_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C1_01_attn_norm.bin" --out "1:$O/C1_04_Kcur_q8k.bin:4368"
run C1_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C1_04_Kcur_q8k.bin" --out "3:$O/C1_05_Kcur.bin:4096"
run C1_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C1_01_attn_norm.bin" --out "1:$O/C1_06_Vcur_q8k.bin:4368"
run C1_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C1_06_Vcur_q8k.bin" --out "3:$O/C1_07_Vcur.bin:4096"
run C1_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C1_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C1_08_Qcur_normed.bin:8192"
run C1_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C1_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C1_09_Kcur_normed.bin:4096"
run C1_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C1_08_Qcur_normed.bin" --in "2:$I/4f98a1b3d0c9f0eec5102693.bin" --out "3:$O/C1_10_Qrope.bin:8192"
run C1_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C1_09_Kcur_normed.bin" --in "2:$I/4f98a1b3d0c9f0eec5102693.bin" --out "3:$O/C1_11_Krope.bin:4096"
run C1_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C1_11_Krope.bin" --in "1:$O/C1_11_Krope.bin" --out "2:$O/C1_12_kpack.bin:2048" --int mode=2 --int n=1024
run C1_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C1_07_Vcur.bin" --in "1:$O/C1_07_Vcur.bin" --out "2:$O/C1_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C1_kcache.bin $O/C0_12_kpack.bin $O/C1_12_kpack.bin
concat $O/C1_vcache.bin $O/C0_13_vpack.bin $O/C1_13_vpack.bin
run C1_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/24b5fb5f37c4cea9d4a74f2c.bin" --in "1:$O/C1_10_Qrope.bin" --in "2:$O/C1_kcache.bin" --in "3:$O/C1_vcache.bin" --out "4:$O/C1_14_kqv_out.bin:8192"
run C1_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C1_14_kqv_out.bin" --out "1:$O/C1_15_attn_out_q8k.bin:8736"
run C1_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C1_15_attn_out_q8k.bin" --out "3:$O/C1_16_attn_out.bin:4096"
run C1_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C1_16_attn_out.bin" --in "1:$I/835059c1d15815325db5d1b6.bin" --out "2:$O/C1_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C1_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C1_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C1_18_ffn_norm.bin:4096"
run C1_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C1_18_ffn_norm.bin" --out "1:$O/C1_19_ffn_gate_q8k.bin:4368"
run C1_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C1_19_ffn_gate_q8k.bin" --out "3:$O/C1_20_ffn_gate.bin:12288"
run C1_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C1_18_ffn_norm.bin" --out "1:$O/C1_21_ffn_up_q8k.bin:4368"
run C1_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C1_21_ffn_up_q8k.bin" --out "3:$O/C1_22_ffn_up.bin:12288"
run C1_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C1_20_ffn_gate.bin" --in "1:$O/C1_22_ffn_up.bin" --out "2:$O/C1_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C1_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C1_23_ffn_swiglu.bin" --out "1:$O/C1_24_ffn_out_q8k.bin:13104"
run C1_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C1_24_ffn_out_q8k.bin" --out "3:$O/C1_25_ffn_out.bin:4096"
run C1_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C1_25_ffn_out.bin" --in "1:$O/C1_17_ffn_inp.bin" --out "2:$O/C1_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step1
run C2_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/69c3105c9a5e18e51c4c9812.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C2_01_attn_norm.bin:4096"
run C2_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C2_01_attn_norm.bin" --out "1:$O/C2_02_Qcur_q8k.bin:4368"
run C2_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C2_02_Qcur_q8k.bin" --out "3:$O/C2_03_Qcur.bin:8192"
run C2_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C2_01_attn_norm.bin" --out "1:$O/C2_04_Kcur_q8k.bin:4368"
run C2_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C2_04_Kcur_q8k.bin" --out "3:$O/C2_05_Kcur.bin:4096"
run C2_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C2_01_attn_norm.bin" --out "1:$O/C2_06_Vcur_q8k.bin:4368"
run C2_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C2_06_Vcur_q8k.bin" --out "3:$O/C2_07_Vcur.bin:4096"
run C2_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C2_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C2_08_Qcur_normed.bin:8192"
run C2_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C2_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C2_09_Kcur_normed.bin:4096"
run C2_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C2_08_Qcur_normed.bin" --in "2:$I/a6d7dc2d8930bf8df4cc5f9f.bin" --out "3:$O/C2_10_Qrope.bin:8192"
run C2_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C2_09_Kcur_normed.bin" --in "2:$I/a6d7dc2d8930bf8df4cc5f9f.bin" --out "3:$O/C2_11_Krope.bin:4096"
run C2_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C2_11_Krope.bin" --in "1:$O/C2_11_Krope.bin" --out "2:$O/C2_12_kpack.bin:2048" --int mode=2 --int n=1024
run C2_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C2_07_Vcur.bin" --in "1:$O/C2_07_Vcur.bin" --out "2:$O/C2_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C2_kcache.bin $O/C0_12_kpack.bin $O/C1_12_kpack.bin $O/C2_12_kpack.bin
concat $O/C2_vcache.bin $O/C0_13_vpack.bin $O/C1_13_vpack.bin $O/C2_13_vpack.bin
run C2_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/194249d55e0fb8c646ba5dae.bin" --in "1:$O/C2_10_Qrope.bin" --in "2:$O/C2_kcache.bin" --in "3:$O/C2_vcache.bin" --out "4:$O/C2_14_kqv_out.bin:8192"
run C2_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C2_14_kqv_out.bin" --out "1:$O/C2_15_attn_out_q8k.bin:8736"
run C2_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C2_15_attn_out_q8k.bin" --out "3:$O/C2_16_attn_out.bin:4096"
run C2_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C2_16_attn_out.bin" --in "1:$I/69c3105c9a5e18e51c4c9812.bin" --out "2:$O/C2_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C2_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C2_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C2_18_ffn_norm.bin:4096"
run C2_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C2_18_ffn_norm.bin" --out "1:$O/C2_19_ffn_gate_q8k.bin:4368"
run C2_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C2_19_ffn_gate_q8k.bin" --out "3:$O/C2_20_ffn_gate.bin:12288"
run C2_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C2_18_ffn_norm.bin" --out "1:$O/C2_21_ffn_up_q8k.bin:4368"
run C2_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C2_21_ffn_up_q8k.bin" --out "3:$O/C2_22_ffn_up.bin:12288"
run C2_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C2_20_ffn_gate.bin" --in "1:$O/C2_22_ffn_up.bin" --out "2:$O/C2_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C2_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C2_23_ffn_swiglu.bin" --out "1:$O/C2_24_ffn_out_q8k.bin:13104"
run C2_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C2_24_ffn_out_q8k.bin" --out "3:$O/C2_25_ffn_out.bin:4096"
run C2_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C2_25_ffn_out.bin" --in "1:$O/C2_17_ffn_inp.bin" --out "2:$O/C2_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step2
run C3_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/67545b24b19b3b1e73274dd6.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C3_01_attn_norm.bin:4096"
run C3_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C3_01_attn_norm.bin" --out "1:$O/C3_02_Qcur_q8k.bin:4368"
run C3_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C3_02_Qcur_q8k.bin" --out "3:$O/C3_03_Qcur.bin:8192"
run C3_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C3_01_attn_norm.bin" --out "1:$O/C3_04_Kcur_q8k.bin:4368"
run C3_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C3_04_Kcur_q8k.bin" --out "3:$O/C3_05_Kcur.bin:4096"
run C3_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C3_01_attn_norm.bin" --out "1:$O/C3_06_Vcur_q8k.bin:4368"
run C3_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C3_06_Vcur_q8k.bin" --out "3:$O/C3_07_Vcur.bin:4096"
run C3_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C3_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C3_08_Qcur_normed.bin:8192"
run C3_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C3_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C3_09_Kcur_normed.bin:4096"
run C3_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C3_08_Qcur_normed.bin" --in "2:$I/a151d83b370f5a1bf8ae7988.bin" --out "3:$O/C3_10_Qrope.bin:8192"
run C3_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C3_09_Kcur_normed.bin" --in "2:$I/a151d83b370f5a1bf8ae7988.bin" --out "3:$O/C3_11_Krope.bin:4096"
run C3_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C3_11_Krope.bin" --in "1:$O/C3_11_Krope.bin" --out "2:$O/C3_12_kpack.bin:2048" --int mode=2 --int n=1024
run C3_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C3_07_Vcur.bin" --in "1:$O/C3_07_Vcur.bin" --out "2:$O/C3_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C3_kcache.bin $O/C0_12_kpack.bin $O/C1_12_kpack.bin $O/C2_12_kpack.bin $O/C3_12_kpack.bin
concat $O/C3_vcache.bin $O/C0_13_vpack.bin $O/C1_13_vpack.bin $O/C2_13_vpack.bin $O/C3_13_vpack.bin
run C3_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/3cef86d6048884a20c9ae771.bin" --in "1:$O/C3_10_Qrope.bin" --in "2:$O/C3_kcache.bin" --in "3:$O/C3_vcache.bin" --out "4:$O/C3_14_kqv_out.bin:8192"
run C3_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C3_14_kqv_out.bin" --out "1:$O/C3_15_attn_out_q8k.bin:8736"
run C3_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C3_15_attn_out_q8k.bin" --out "3:$O/C3_16_attn_out.bin:4096"
run C3_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C3_16_attn_out.bin" --in "1:$I/67545b24b19b3b1e73274dd6.bin" --out "2:$O/C3_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C3_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C3_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C3_18_ffn_norm.bin:4096"
run C3_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C3_18_ffn_norm.bin" --out "1:$O/C3_19_ffn_gate_q8k.bin:4368"
run C3_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C3_19_ffn_gate_q8k.bin" --out "3:$O/C3_20_ffn_gate.bin:12288"
run C3_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C3_18_ffn_norm.bin" --out "1:$O/C3_21_ffn_up_q8k.bin:4368"
run C3_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C3_21_ffn_up_q8k.bin" --out "3:$O/C3_22_ffn_up.bin:12288"
run C3_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C3_20_ffn_gate.bin" --in "1:$O/C3_22_ffn_up.bin" --out "2:$O/C3_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C3_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C3_23_ffn_swiglu.bin" --out "1:$O/C3_24_ffn_out_q8k.bin:13104"
run C3_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C3_24_ffn_out_q8k.bin" --out "3:$O/C3_25_ffn_out.bin:4096"
run C3_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C3_25_ffn_out.bin" --in "1:$O/C3_17_ffn_inp.bin" --out "2:$O/C3_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step3
run C4_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/29e9d77d995e3985e2a2181a.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C4_01_attn_norm.bin:4096"
run C4_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C4_01_attn_norm.bin" --out "1:$O/C4_02_Qcur_q8k.bin:4368"
run C4_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C4_02_Qcur_q8k.bin" --out "3:$O/C4_03_Qcur.bin:8192"
run C4_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C4_01_attn_norm.bin" --out "1:$O/C4_04_Kcur_q8k.bin:4368"
run C4_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C4_04_Kcur_q8k.bin" --out "3:$O/C4_05_Kcur.bin:4096"
run C4_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C4_01_attn_norm.bin" --out "1:$O/C4_06_Vcur_q8k.bin:4368"
run C4_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C4_06_Vcur_q8k.bin" --out "3:$O/C4_07_Vcur.bin:4096"
run C4_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C4_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C4_08_Qcur_normed.bin:8192"
run C4_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C4_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C4_09_Kcur_normed.bin:4096"
run C4_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C4_08_Qcur_normed.bin" --in "2:$I/33a0cb1b3df389ba952ab88d.bin" --out "3:$O/C4_10_Qrope.bin:8192"
run C4_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C4_09_Kcur_normed.bin" --in "2:$I/33a0cb1b3df389ba952ab88d.bin" --out "3:$O/C4_11_Krope.bin:4096"
run C4_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C4_11_Krope.bin" --in "1:$O/C4_11_Krope.bin" --out "2:$O/C4_12_kpack.bin:2048" --int mode=2 --int n=1024
run C4_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C4_07_Vcur.bin" --in "1:$O/C4_07_Vcur.bin" --out "2:$O/C4_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C4_kcache.bin $O/C0_12_kpack.bin $O/C1_12_kpack.bin $O/C2_12_kpack.bin $O/C3_12_kpack.bin $O/C4_12_kpack.bin
concat $O/C4_vcache.bin $O/C0_13_vpack.bin $O/C1_13_vpack.bin $O/C2_13_vpack.bin $O/C3_13_vpack.bin $O/C4_13_vpack.bin
run C4_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/e22b35e844951234376722b5.bin" --in "1:$O/C4_10_Qrope.bin" --in "2:$O/C4_kcache.bin" --in "3:$O/C4_vcache.bin" --out "4:$O/C4_14_kqv_out.bin:8192"
run C4_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C4_14_kqv_out.bin" --out "1:$O/C4_15_attn_out_q8k.bin:8736"
run C4_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C4_15_attn_out_q8k.bin" --out "3:$O/C4_16_attn_out.bin:4096"
run C4_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C4_16_attn_out.bin" --in "1:$I/29e9d77d995e3985e2a2181a.bin" --out "2:$O/C4_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C4_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C4_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C4_18_ffn_norm.bin:4096"
run C4_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C4_18_ffn_norm.bin" --out "1:$O/C4_19_ffn_gate_q8k.bin:4368"
run C4_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C4_19_ffn_gate_q8k.bin" --out "3:$O/C4_20_ffn_gate.bin:12288"
run C4_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C4_18_ffn_norm.bin" --out "1:$O/C4_21_ffn_up_q8k.bin:4368"
run C4_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C4_21_ffn_up_q8k.bin" --out "3:$O/C4_22_ffn_up.bin:12288"
run C4_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C4_20_ffn_gate.bin" --in "1:$O/C4_22_ffn_up.bin" --out "2:$O/C4_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C4_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C4_23_ffn_swiglu.bin" --out "1:$O/C4_24_ffn_out_q8k.bin:13104"
run C4_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C4_24_ffn_out_q8k.bin" --out "3:$O/C4_25_ffn_out.bin:4096"
run C4_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C4_25_ffn_out.bin" --in "1:$O/C4_17_ffn_inp.bin" --out "2:$O/C4_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step4
run C5_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/325ee7b002cbcb5f83ab5bef.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C5_01_attn_norm.bin:4096"
run C5_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C5_01_attn_norm.bin" --out "1:$O/C5_02_Qcur_q8k.bin:4368"
run C5_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C5_02_Qcur_q8k.bin" --out "3:$O/C5_03_Qcur.bin:8192"
run C5_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C5_01_attn_norm.bin" --out "1:$O/C5_04_Kcur_q8k.bin:4368"
run C5_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C5_04_Kcur_q8k.bin" --out "3:$O/C5_05_Kcur.bin:4096"
run C5_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C5_01_attn_norm.bin" --out "1:$O/C5_06_Vcur_q8k.bin:4368"
run C5_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C5_06_Vcur_q8k.bin" --out "3:$O/C5_07_Vcur.bin:4096"
run C5_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C5_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C5_08_Qcur_normed.bin:8192"
run C5_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C5_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C5_09_Kcur_normed.bin:4096"
run C5_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C5_08_Qcur_normed.bin" --in "2:$I/dea2dcc45f7aa2e846e2025c.bin" --out "3:$O/C5_10_Qrope.bin:8192"
run C5_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C5_09_Kcur_normed.bin" --in "2:$I/dea2dcc45f7aa2e846e2025c.bin" --out "3:$O/C5_11_Krope.bin:4096"
run C5_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C5_11_Krope.bin" --in "1:$O/C5_11_Krope.bin" --out "2:$O/C5_12_kpack.bin:2048" --int mode=2 --int n=1024
run C5_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C5_07_Vcur.bin" --in "1:$O/C5_07_Vcur.bin" --out "2:$O/C5_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C5_kcache.bin $O/C0_12_kpack.bin $O/C1_12_kpack.bin $O/C2_12_kpack.bin $O/C3_12_kpack.bin $O/C4_12_kpack.bin $O/C5_12_kpack.bin
concat $O/C5_vcache.bin $O/C0_13_vpack.bin $O/C1_13_vpack.bin $O/C2_13_vpack.bin $O/C3_13_vpack.bin $O/C4_13_vpack.bin $O/C5_13_vpack.bin
run C5_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/915fbc750538e049e32f4935.bin" --in "1:$O/C5_10_Qrope.bin" --in "2:$O/C5_kcache.bin" --in "3:$O/C5_vcache.bin" --out "4:$O/C5_14_kqv_out.bin:8192"
run C5_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C5_14_kqv_out.bin" --out "1:$O/C5_15_attn_out_q8k.bin:8736"
run C5_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C5_15_attn_out_q8k.bin" --out "3:$O/C5_16_attn_out.bin:4096"
run C5_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C5_16_attn_out.bin" --in "1:$I/325ee7b002cbcb5f83ab5bef.bin" --out "2:$O/C5_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C5_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C5_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C5_18_ffn_norm.bin:4096"
run C5_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C5_18_ffn_norm.bin" --out "1:$O/C5_19_ffn_gate_q8k.bin:4368"
run C5_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C5_19_ffn_gate_q8k.bin" --out "3:$O/C5_20_ffn_gate.bin:12288"
run C5_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C5_18_ffn_norm.bin" --out "1:$O/C5_21_ffn_up_q8k.bin:4368"
run C5_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C5_21_ffn_up_q8k.bin" --out "3:$O/C5_22_ffn_up.bin:12288"
run C5_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C5_20_ffn_gate.bin" --in "1:$O/C5_22_ffn_up.bin" --out "2:$O/C5_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C5_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C5_23_ffn_swiglu.bin" --out "1:$O/C5_24_ffn_out_q8k.bin:13104"
run C5_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C5_24_ffn_out_q8k.bin" --out "3:$O/C5_25_ffn_out.bin:4096"
run C5_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C5_25_ffn_out.bin" --in "1:$O/C5_17_ffn_inp.bin" --out "2:$O/C5_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step5
run C6_01_attn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$I/4a4c699f31d93ecb2c77b6d8.bin" --in "2:$I/2eee4001cd35fc3003c88f35.bin" --out "3:$O/C6_01_attn_norm.bin:4096"
run C6_02_Qcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C6_01_attn_norm.bin" --out "1:$O/C6_02_Qcur_q8k.bin:4368"
run C6_03_Qcur ggml_matvec_qk.comp --groups 32 --in "0:$I/d6208255a7e4f8905c3ec4e6.bin" --in "1:$I/2a3959e25f0736296a521b59.bin" --in "2:$O/C6_02_Qcur_q8k.bin" --out "3:$O/C6_03_Qcur.bin:8192"
run C6_04_Kcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C6_01_attn_norm.bin" --out "1:$O/C6_04_Kcur_q8k.bin:4368"
run C6_05_Kcur ggml_matvec_qk.comp --groups 16 --in "0:$I/cd104655660a1a2a7f686729.bin" --in "1:$I/5cdcb9e7b983544d114d8ad8.bin" --in "2:$O/C6_04_Kcur_q8k.bin" --out "3:$O/C6_05_Kcur.bin:4096"
run C6_06_Vcur_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C6_01_attn_norm.bin" --out "1:$O/C6_06_Vcur_q8k.bin:4368"
run C6_07_Vcur ggml_matvec_qk.comp --groups 16 --in "0:$I/09b46dca461fd35c05492049.bin" --in "1:$I/4b7286306583a0ab193a610f.bin" --in "2:$O/C6_06_Vcur_q8k.bin" --out "3:$O/C6_07_Vcur.bin:4096"
run C6_08_Qcur_normed ggml_rms_norm_mul.comp --groups 16 --in "0:$I/249e2ddd30e6c7a12ea58388.bin" --in "1:$O/C6_03_Qcur.bin" --in "2:$I/947dfb943be2fa3ae139fe58.bin" --out "3:$O/C6_08_Qcur_normed.bin:8192"
run C6_09_Kcur_normed ggml_rms_norm_mul.comp --groups 8 --in "0:$I/e263f4903035b58a0cab8b17.bin" --in "1:$O/C6_05_Kcur.bin" --in "2:$I/af969c10eb9014d01f69eefd.bin" --out "3:$O/C6_09_Kcur_normed.bin:4096"
run C6_10_Qrope ggml_rope_neox.comp --groups 16 --in "0:$I/1f818afc755df113fcba7351.bin" --in "1:$O/C6_08_Qcur_normed.bin" --in "2:$I/b75a6f6916bfb5604e6c487d.bin" --out "3:$O/C6_10_Qrope.bin:8192"
run C6_11_Krope ggml_rope_neox.comp --groups 8 --in "0:$I/58108b595d5232974458bfa9.bin" --in "1:$O/C6_09_Kcur_normed.bin" --in "2:$I/b75a6f6916bfb5604e6c487d.bin" --out "3:$O/C6_11_Krope.bin:4096"
run C6_12_kpack ggml_eltwise.comp --groups 16 --in "0:$O/C6_11_Krope.bin" --in "1:$O/C6_11_Krope.bin" --out "2:$O/C6_12_kpack.bin:2048" --int mode=2 --int n=1024
run C6_13_vpack ggml_eltwise.comp --groups 16 --in "0:$O/C6_07_Vcur.bin" --in "1:$O/C6_07_Vcur.bin" --out "2:$O/C6_13_vpack.bin:2048" --int mode=2 --int n=1024
concat $O/C6_kcache.bin $O/C0_12_kpack.bin $O/C1_12_kpack.bin $O/C2_12_kpack.bin $O/C3_12_kpack.bin $O/C4_12_kpack.bin $O/C5_12_kpack.bin $O/C6_12_kpack.bin
concat $O/C6_vcache.bin $O/C0_13_vpack.bin $O/C1_13_vpack.bin $O/C2_13_vpack.bin $O/C3_13_vpack.bin $O/C4_13_vpack.bin $O/C5_13_vpack.bin $O/C6_13_vpack.bin
run C6_14_kqv_out ggml_fa_f16.comp --groups 16 --in "0:$I/d19a0f1063fcf4098c0843ef.bin" --in "1:$O/C6_10_Qrope.bin" --in "2:$O/C6_kcache.bin" --in "3:$O/C6_vcache.bin" --out "4:$O/C6_14_kqv_out.bin:8192"
run C6_15_attn_out_q8k ggml_q8k_quantize.comp --groups 8 --in "0:$O/C6_14_kqv_out.bin" --out "1:$O/C6_15_attn_out_q8k.bin:8736"
run C6_16_attn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/664a006ebc4a4d018e2ca9f8.bin" --in "1:$I/cbb2b7e77c305799281b1684.bin" --in "2:$O/C6_15_attn_out_q8k.bin" --out "3:$O/C6_16_attn_out.bin:4096"
run C6_17_ffn_inp ggml_eltwise.comp --groups 16 --in "0:$O/C6_16_attn_out.bin" --in "1:$I/4a4c699f31d93ecb2c77b6d8.bin" --out "2:$O/C6_17_ffn_inp.bin:4096" --int mode=0 --int n=1024
run C6_18_ffn_norm ggml_rms_norm_mul.comp --groups 1 --in "0:$I/55ba93c9b026f82c8e5e5047.bin" --in "1:$O/C6_17_ffn_inp.bin" --in "2:$I/db89f70a912606b5e59fc02e.bin" --out "3:$O/C6_18_ffn_norm.bin:4096"
run C6_19_ffn_gate_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C6_18_ffn_norm.bin" --out "1:$O/C6_19_ffn_gate_q8k.bin:4368"
run C6_20_ffn_gate ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/3965f4bd3bc6c6bdd3ee3d99.bin" --in "2:$O/C6_19_ffn_gate_q8k.bin" --out "3:$O/C6_20_ffn_gate.bin:12288"
run C6_21_ffn_up_q8k ggml_q8k_quantize.comp --groups 4 --in "0:$O/C6_18_ffn_norm.bin" --out "1:$O/C6_21_ffn_up_q8k.bin:4368"
run C6_22_ffn_up ggml_matvec_qk.comp --groups 48 --in "0:$I/736022d31f16c2fc2828a11f.bin" --in "1:$I/c6e1ad3481cf1c5d8bdb8b28.bin" --in "2:$O/C6_21_ffn_up_q8k.bin" --out "3:$O/C6_22_ffn_up.bin:12288"
run C6_23_ffn_swiglu ggml_eltwise.comp --groups 48 --in "0:$O/C6_20_ffn_gate.bin" --in "1:$O/C6_22_ffn_up.bin" --out "2:$O/C6_23_ffn_swiglu.bin:12288" --int mode=1 --int n=3072
run C6_24_ffn_out_q8k ggml_q8k_quantize.comp --groups 12 --in "0:$O/C6_23_ffn_swiglu.bin" --out "1:$O/C6_24_ffn_out_q8k.bin:13104"
run C6_25_ffn_out ggml_matvec_qk.comp --groups 16 --in "0:$I/c8f610f617282f38fe4dbcf3.bin" --in "1:$I/ed55e07c37ff9f0fb85bf09b.bin" --in "2:$O/C6_24_ffn_out_q8k.bin" --out "3:$O/C6_25_ffn_out.bin:4096"
run C6_26_l_out ggml_eltwise.comp --groups 16 --in "0:$O/C6_25_ffn_out.bin" --in "1:$O/C6_17_ffn_inp.bin" --out "2:$O/C6_26_l_out.bin:4096" --int mode=0 --int n=1024
checkpoint C_step6
